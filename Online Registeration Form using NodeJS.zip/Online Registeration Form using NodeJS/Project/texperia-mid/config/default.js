'use strict';
const config = {
	db: {
		uri: 'mongodb://localhost/Texperia'
	},
	jwt: {
		secret: (process.env.JWT_SECRET || 'test-jwt-secret')
	},
	nodemailer: {
		host: 'smtp.gmail.com',
		port: 465,
		secure: true,
		auth: {
			user: 'silverjoyboy@gmail.com',
			pass: 'w3e2r5t4'
		}
	},
	PORT: process.env.PORT || 3002
};
module.exports = config;
