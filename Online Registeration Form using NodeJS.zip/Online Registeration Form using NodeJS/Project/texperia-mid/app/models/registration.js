'use strict';
const mongoose = require('mongoose');
const uuid = require('uuid');
const Schema = mongoose.Schema;
const mailServ = require('../lib/email');
const StudentSchema = new Schema({
	id: {type: String, default: uuid},
	regId: {type: Number},
	name: {type: String, required: true},
	degree: {type: String, required: true},
	branch: {type: String, required: true},
	college: {type: String, required: true},
	city: {type: String, required: true},
	email: {type: String, required: true, unique: true},
	mobile: {type: String, required: true}
});
function outputDataGenerator(data){
	return {
		regId: data.regId,
		name: data.name,
		degree: data.degree,
		branch: data.branch,
		college: data.college,
		city: data.city,
		email: data.email,
		mobile: data.mobile
	}
}

function newRegistration(data) {
	const self = this;
	return new Promise((resolve, reject) => {
		self.findOne({email: data.email})
		.then(student => {
			if(student) {
				const error = new Error('This email id is already registered');
				return reject(error);
			} else {
				 return self.count({}); 
			}
		})
		.then(count => {
			data.regId = count + 1000;
			const student = new Student(outputDataGenerator(data));
			return student.save();
		})
		.then(() => {
			return mailServ.nodeMailer(data.email, data.regId, data.name);
		})
		.then(info => {
			if(info){
				return resolve({
					isSuccess: true,
					message: 'Thank you! regId is sent to your mail'
				})
			}
		})
		.catch(err => {
			return reject(err);
		})

	})
}

StudentSchema.statics.newRegistration = newRegistration;
const Student = mongoose.model('participants', StudentSchema);
module.exports = Student;
