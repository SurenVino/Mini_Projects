'use strict';
const db = require('./db');
const student = require('./registration');
module.exports = {
	db,
	student
};