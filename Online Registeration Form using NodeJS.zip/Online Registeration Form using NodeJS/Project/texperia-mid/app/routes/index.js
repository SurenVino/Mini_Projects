'use strict';
const registration = require('./registration');
module.exports = app => {
	 // app.use('/home/*', isAuthorized); 
	 app.use('/api', registration);
};