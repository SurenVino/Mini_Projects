'use strict';
const express = require('express');
const mongoose = require('mongoose');
const path = require('path');
const Student = require(path.resolve('./app/models')).student;
const router = express.Router();

router.route('/')
.post((req, res) => {
	console.log(__dirname);
	Student.newRegistration(req.body)
	.then(data => {
		res.json(data);
	})
	.catch(err => {

		res.json({isSuccess: false, message: err.toString()});
	})
})

module.exports = router;