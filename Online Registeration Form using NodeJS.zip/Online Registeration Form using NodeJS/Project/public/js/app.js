'use strict';
(function(){
	var app = angular.module('Texperia', []);
	app.controller('registrationCtrl',['$scope', '$http', registration]);
	function registration($scope, $http){
        $scope.errors={};
		$scope.register = function() {
			console.log($scope.user)
			var name = $scope.user.name;
			var email = $scope.user.email;
			var mobile = $scope.user.mobile;
			var college = $scope.user.college;
			var degree = $scope.user.degree;
			var branch = $scope.user.branch;
			var city = $scope.user.city;
			var data = {name, email, mobile, college, degree, branch, city};
			if(name && email && mobile && college && degree && branch && city) {
				$http.post('http://localhost:3002/api/', data)
				.then(function(res){
					console.log(res.data);
                    if(res.data.isSuccess){
                        $scope.errors.hasNoError=true;
                        $scope.errors.hasError=false;
                        $scope.errors.message=res.data.message;
                        $scope.user = {};
                    }else{
                        $scope.errors.hasError=true;
                         $scope.errors.hasNoError=false;
                        $scope.errors.message=res.data.message;
                    }
				})
			}
		}
	}
})();
