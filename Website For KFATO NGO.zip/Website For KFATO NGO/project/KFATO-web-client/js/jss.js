    $(document).ready(function(){
      $('.slider').slider();
     $('.modal').modal();
     $('select').material_select();
   });

    $(".button-collapse").sideNav();

  $('#modal1').modal('open');

  $('#modal1').modal('close');