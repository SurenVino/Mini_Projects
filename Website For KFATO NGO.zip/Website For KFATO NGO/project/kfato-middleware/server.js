'use strict';
const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const app = express();
app.use(cors());
require('./app/models');
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended: true}));
require('./app/routes')(app);
app.listen(8003, () => console.log("server running at 8003"))