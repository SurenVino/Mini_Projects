const blood = require('./blood');
module.exports = app => {
	 // app.use('/home/*', isAuthorized); 
	 app.use('/api', blood);
 
};
