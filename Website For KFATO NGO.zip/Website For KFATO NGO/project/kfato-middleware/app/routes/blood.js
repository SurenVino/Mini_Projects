const express = require('express');
const mongoose = require('mongoose');
const path = require('path');
const blood = require(path.resolve('./app/models')).bloodDonor;
const router = express.Router();

function save(data){
	return new Promise((resolve, reject)=>{
		const donordata = new blood(data);
		donordata.save()
		.then(()=>{
			
			return resolve({
				isSuccess: true,
				message:'success'
			});
		})
		.catch(err=>{
			return reject(err);
		})
	})
}
router.route('/')

.post((req, res) => {
	const body = req.body;
	blood.findOne({email: body.email})
	.then(data=>{
		if(!data){
			return save(body);
		} else {
			res.send({
				isSuccess: false,
				message: 'already exist'
			})
		}
	})
	.then((data)=>{
		res.send(data)
	})
	.catch(err=>{
		
		res.send('some thing went wrong');
	})
})

.get((req, res)=>{
	blood.find(req.query, {_id:false, __v:false})
	.then(data => {
		if(data.length ===0){
			res.send({
				isSuccess:false,
				message: 'Not found'
			});
		}else{
			res.send({
				isSuccess: true,
				list: data
			});
		}
	})
	.catch(err=>{
		res.send('some thing went wrong');
	})
})

module.exports = router;