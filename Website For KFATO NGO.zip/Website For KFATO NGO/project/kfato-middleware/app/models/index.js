const db = require('./db');
const bloodDonor = require('./schema');
module.exports = {db, bloodDonor};