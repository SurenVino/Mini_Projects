'use strict';
const express = require('express');
const mongoose = require('mongoose');
const router = express.Router();
const Schema = mongoose.Schema;
const bloodDonorSchema = new Schema({
	name : {type: String, required: true},
	bloodgroup: {type: String, required: true},
	mobile: {type: String, required: true},
	email: {type: String, required: true, unique: true},
	city: {type: String, required: true},
	pincode: {type: String, required: true}
});
const bloodDonor = mongoose.model('blooddonor', bloodDonorSchema);
module.exports = bloodDonor;